
<html>
<head>
<title>Timlab-</title>
<link rel="stylesheet" href="style/style.css" type="text/css"/>
</head>
<body>
<div class="head"><center>
<img src="image/timlab.png" class="imm"/>
</center>
</div>

<?php
if(isset($_POST["codevalidation"]) && !empty($_POST["codevalidation"])){
	
	require_once("functions.php");
	$t = 460 + $_POST["t"];
	$p = $_POST["p"];
	
	$cone = $_POST["cone"]/100;
	$ctwo = $_POST["ctwo"]/100;
	$cthree = $_POST["cthree"]/100;
	
	$icfour = $_POST["icfour"]/100;
	$ncfour = $_POST["ncfour"]/100;
	$icf = $_POST["icf"]/100;
	$ncf = $_POST["ncf"]/100;
	$ncsix = $_POST["ncsix"]/100;
	$nch = $_POST["ncs"]/100;
	$nco = $_POST["nco"]/100;
	
	$ncn = $_POST["ncn"]/100;
	$ncd = $_POST["ncd"]/100;
	
	$et = $_POST["et"]/100;
	$pln = $_POST["pln"]/100;
	
	$nl = $_POST["nl"];
	$ng = $_POST["ng"];
	
	$mmasss = array(16.043,28.054,30.07,42.08,44.097,58.124,58.124,72.151,72.151,86.178,100.205,114.232,128.259,142.286);
	
	$mmass = array(16.043,28.054,30.07,42.08,44.097,58.124,58.124,72.151,72.151,86.178,100.205,114.232,128.259,142.286);
	$arrayx = array(liquid($cone,$ng,form_one(292860,8.2445,0.8951,59.8465,$t,$p)),liquid($et,$ng,form_one(600076.9,7.90595,0.84677,42.94594,$t,$p)),liquid($ctwo,$ng,form_one(687248.2,7.90694,0.866,49.02654,$t,$p)),liquid($pln,$ng,form_one(923484.7,7.71725,0.87871,47.67624,$t,$p)),liquid($cthree,$ng,form_two(970688.6,7.15059,0.76984,6.9022,$t,$p)),liquid($icfour,$ng,form_one(1166846,7.72668,0.92213,0,$t,$p)),liquid($ncfour,$ng,form_one(1280557,7.94986,0.96455,0,$t,$p)),liquid($icf,$ng,form_one(1481583,7.58071,0.93159,0,$t,$p)),liquid($ncf,$ng,form_one(1524891,7.33129,0.89143,0,$t,$p)),liquid($ncsix,$ng,form_one(1778901,6.96783,0.84634,0,$t,$p)),liquid($nch,$ng,form_one(2013803,6.52914,0.79543,0,$t,$p)),liquid($nco,$ng,form_three(7646.816,12.48457,0.73152,$t,$p)),liquid($ncn,$ng,form_one(2551040,5.69313,0.67818,0,$t,$p)),liquid($ncd,$ng,form_three(9760.457,13.80354,0.7147,$t,$p)));
	$arrayy = array(gas($cone,$nl,form_one(292860,8.2445,0.8951,59.8465,$t,$p)),gas($et,$nl,form_one(600076.9,7.90595,0.84677,42.94594,$t,$p)),gas($ctwo,$nl,form_one(687248.2,7.90694,0.866,49.02654,$t,$p)),gas($pln,$nl,form_one(923484.7,7.71725,0.87871,47.67624,$t,$p)),gas($cthree,$nl,form_two(970688.6,7.15059,0.76984,6.9022,$t,$p)),gas($icfour,$nl,form_one(1166846,7.72668,0.92213,0,$t,$p)),gas($ncfour,$nl,form_one(1280557,7.94986,0.96455,0,$t,$p)),gas($icf,$nl,form_one(1481583,7.58071,0.93159,0,$t,$p)),gas($ncf,$nl,form_one(1524891,7.33129,0.89143,0,$t,$p)),gas($ncsix,$nl,form_one(1778901,6.96783,0.84634,0,$t,$p)),gas($nch,$nl,form_one(2013803,6.52914,0.79543,0,$t,$p)),gas($nco,$nl,form_three(7646.816,12.48457,0.73152,$t,$p)),gas($ncn,$nl,form_one(2551040,5.69313,0.67818,0,$t,$p)),gas($ncd,$nl,form_three(9760.457,13.80354,0.7147,$t,$p)));
	
	
	$msum = array_sum($mmass);
	$summx = array_sum($arrayx) ;
	

		
	
	if(($summx > 0.9) && ($summx >= 0.95)){
		
		$summx = round(array_sum($arrayx),1) ;
		
		}
		else{
			
			$summx = round(array_sum($arrayx),4) ;
			}
			
	
	$summy = array_sum($arrayy);
	
	
		if(($summy > 0.9) && ($summy >= 0.95)){
		
		$summy = round(array_sum($arrayy),1);
		
		}
		else{
			
				$summy = round(array_sum($arrayy),4);
			}
	
	


	
	
	
	?>
	
	<table cellspacing="1px" border="0px" width="94%" class="tab"  cellpadding="15px">
	<tr align="left">
	<th>Mixture Composition</th>
	<th>k-Value (K<sub>j</sub>)</th>
	<th>Mole Fraction (Z<sub>j</sub>)</th>
	<th>Liquid Composition(X<sub>j</sub>)</th>
	<th>Gas Composition (Y<sub>j</sub>)</th>
	<th>Molar mass (M<sub>j</sub>)</th>
	</tr>
	
	<tr>
	<td>Methane (C<sub>1</sub>)</td>
	<td><?php echo form_one(292860,8.2445,0.8951,59.8465,$t,$p);?></td>
	<td><?php echo $cone;?></td>
	<td><?php echo liquid($cone,$ng,form_one(292860,8.2445,0.8951,59.8465,$t,$p));?></td>
	<td><?php echo gas($cone,$nl,form_one(292860,8.2445,0.8951,59.8465,$t,$p));?></td>
	<td><?php echo $mmass[0];?></td>
	</tr>
	
	
			<tr>
	<td>Ethylene </td>
	<td><?php echo form_one(600076.9,7.90595,0.84677,42.94594,$t,$p);?></td>
	<td><?php echo $et;?></td>
	<td><?php echo liquid($et,$ng,form_one(600076.9,7.90595,0.84677,42.94594,$t,$p));?></td>
	<td><?php echo gas($et,$nl,form_one(600076.9,7.90595,0.84677,42.94594,$t,$p));?></td>
	<td><?php echo $mmass[1];?></td>
	</tr>
	
	
		<tr>
	<td>Ethane (C<sub>2</sub>)</td>
	<td><?php echo form_one(687248.2,7.90694,0.866,49.02654,$t,$p);?></td>
	<td><?php echo $ctwo;?></td>
	<td><?php echo liquid($ctwo,$ng,form_one(687248.2,7.90694,0.866,49.02654,$t,$p));?></td>
	<td><?php echo gas($ctwo,$nl,form_one(687248.2,7.90694,0.866,49.02654,$t,$p));?></td>
	<td><?php echo $mmass[2];?></td>
	</tr>
	
	
	
			<tr>
	<td>Propylene</td>
	<td><?php echo form_one(923484.7,7.71725,0.87871,47.67624,$t,$p);?></td>
	<td><?php echo $pln;?></td>
	<td><?php echo liquid($pln,$ng,form_one(923484.7,7.71725,0.87871,47.67624,$t,$p));?></td>
	<td><?php echo gas($pln,$nl,form_one(923484.7,7.71725,0.87871,47.67624,$t,$p));?></td>
	<td><?php echo $mmass[3];?></td>
	</tr>
	
		<tr>
	<td>Propane (C<sub>3</sub>)</td>
	<td><?php echo form_two(970688.6,7.15059,0.76984,6.9022,$t,$p);?></td>
	<td><?php echo $cthree;?></td>
	<td><?php echo liquid($cthree,$ng,form_two(970688.6,7.15059,0.76984,6.9022,$t,$p));?></td>
	<td><?php echo gas($cthree,$nl,form_two(970688.6,7.15059,0.76984,6.9022,$t,$p));?></td>
	<td><?php echo $mmass[4];?></td>
	</tr>
	
		<tr>
	<td>i-Butane (i-C<sub>4</sub>)</td>
	<td><?php echo form_one(1166846,7.72668,0.92213,0,$t,$p);?></td>
	<td><?php echo $icfour;?></td>
	<td><?php echo liquid($icfour,$ng,form_one(1166846,7.72668,0.92213,0,$t,$p));?></td>
	<td><?php echo gas($icfour,$nl,form_one(1166846,7.72668,0.92213,0,$t,$p));?></td>
	<td><?php echo $mmass[5];?></td>
	</tr>
	
		<tr>
	<td>n-Butane (n-C<sub>4</sub>)</td>
	<td><?php echo form_one(1280557,7.94986,0.96455,0,$t,$p);?></td>
	<td><?php echo $ncfour;?></td>
	<td><?php echo liquid($ncfour,$ng,form_one(1280557,7.94986,0.96455,0,$t,$p));?></td>
	<td><?php echo gas($ncfour,$nl,form_one(1280557,7.94986,0.96455,0,$t,$p));?></td>
	<td><?php echo $mmass[6];?></td>
	</tr>
	
		<tr>
	<td>i-Pentane (i-C<sub>5</sub>)</td>
	<td><?php echo form_one(1481583,7.58071,0.93159,0,$t,$p);?></td>
	<td><?php echo $icf;?></td>
	<td><?php echo liquid($icf,$ng,form_one(1481583,7.58071,0.93159,0,$t,$p));?></td>
	<td><?php echo gas($icf,$nl,form_one(1481583,7.58071,0.93159,0,$t,$p));?></td>
	<td><?php echo $mmass[7];?></td>
	</tr>
	
	
		<tr>
	<td>n-Pentane (n-C<sub>5</sub>)</td>
	<td><?php echo form_one(1524891,7.33129,0.89143,0,$t,$p) ;?></td>
	<td><?php echo $ncf;?></td>
	<td><?php echo liquid($ncf,$ng,form_one(1524891,7.33129,0.89143,0,$t,$p));?></td>
	<td><?php echo gas($ncf,$nl,form_one(1524891,7.33129,0.89143,0,$t,$p));?></td>
	<td><?php echo $mmass[8];?></td>
	</tr>
	
	<tr>
	<td>n-Hexane (n-C<sub>6</sub>)</td>
	<td><?php echo form_one(1778901,6.96783,0.84634,0,$t,$p);?></td>
	<td><?php echo $ncsix;?></td>
	<td><?php echo liquid($ncsix,$ng,form_one(1778901,6.96783,0.84634,0,$t,$p));?></td>
	<td><?php echo gas($ncsix,$nl,form_one(1778901,6.96783,0.84634,0,$t,$p));?></td>
	<td><?php echo $mmass[9];?></td>
	</tr>
	
	
	<tr>
	<td>n-Heptane (n-C<sub>7</sub>)</td>
	<td><?php echo form_one(2013803,6.52914,0.79543,0,$t,$p);?></td>
	<td><?php echo $nch;?></td>
	<td><?php echo liquid($nch,$ng,form_one(2013803,6.52914,0.79543,0,$t,$p));?></td>
	<td><?php echo gas($nch,$nl,form_one(2013803,6.52914,0.79543,0,$t,$p));?></td>
	<td><?php echo $mmass[10];?></td>
	</tr>
	
	
	<tr>
	<td>n-Octane (n-C<sub>8</sub>)</td>
	<td><?php echo form_three(7646.816,12.48457,0.73152,$t,$p);?></td>
	<td><?php echo $nco;?></td>
	<td><?php echo liquid($nco,$ng,form_three(7646.816,12.48457,0.73152,$t,$p));?></td>
	<td><?php echo gas($nco,$nl,form_three(7646.816,12.48457,0.73152,$t,$p));?></td>
	<td><?php echo $mmass[11];?></td>
	</tr>
	
		<tr>
	<td>n-Nonane (n-C<sub>9</sub>)</td>
	<td><?php echo form_one(2551040,5.69313,0.67818,0,$t,$p);?></td>
	<td><?php echo $ncn;?></td>
	<td><?php echo liquid($ncn,$ng,form_one(2551040,5.69313,0.67818,0,$t,$p));?></td>
	<td><?php echo gas($ncn,$nl,form_one(2551040,5.69313,0.67818,0,$t,$p));?></td>
	<td><?php echo $mmass[12];?></td>
	</tr>
	
		<tr>
	<td>n-Decane (n-C<sub>10</sub>)</td>
	<td><?php echo form_three(9760.457,13.80354,0.7147,$t,$p);?></td>
	<td><?php echo $ncd;?></td>
	<td><?php echo liquid($ncd,$ng,form_three(9760.457,13.80354,0.7147,$t,$p));?></td>
	<td><?php echo gas($ncd,$nl,form_three(9760.457,13.80354,0.7147,$t,$p));?></td>
	<td><?php echo $mmass[13];?></td>
	</tr>
	
	<tr align="left">
	<th></th>
	<th></th>
	<th></th>
	<th>&sum;X<sub>j</sub> = <?php echo $summx;?></th>
	<th>&sum;Y<sub>j</sub> = <?php echo $summy ;?></th>
	<th>&sum;M<sub>j</sub> = <?php echo $msum ;?></th>
	</tr>
	
	
	</table>
	
	<?php
	
	
	
	
	
	/**
	$form_one = exp(((-$a/($t*$t)) + $b - ($c * log($p)) + ($d/($p*$p))));
	
	$form_two = exp(((-$a/($t*$t)) + $b - ($c * log($p)) + ($d/($p))));
	
	$form_three = exp(((-$a/($t)) + $b - ($c * log($p))));
	
	*/

		for($i=0;$i <= sizeof($mmass);$i++){
		
			$mxj[] = array_shift($mmass) * array_shift($arrayx);
		
		}
		$timx = array_sum($mxj);
		
		
		for($i=0;$i <= sizeof($mmasss);$i++){
			
		
			$myj[] = array_shift($mmasss) * array_shift($arrayy);
		
		}
		$timy = array_sum($myj);

		$sp = round($timy/28.9625,4);
		
		echo "<h2 style='margin-left:20pt;margin-bottom:20pt;padding:10px;'>&sum;M<sub>j</sub>X<sub>j</sub> = $timx &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&sum;M<sub>j</sub>Y<sub>j</sub> = $timy&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Specific Gravity = $sp</h2>";
	
	
	
	}
	else{
	
	?>
	<script type="text/javascript" language="javascript">
	alert("Parameter Missing!pls try again");
	window.location="./";
	</script>
	<?php	
		
		}

?>


</body>
</html>

