<?php
/**
 * Charts 4 PHP
 *
 * @author Shani <support@chartphp.com> - http://www.chartphp.com
 * @version 1.2.3
 * @license: see license.txt included in package
 */
 
include("../../lib/inc/chartphp_dist.php");

$p = new chartphp();

$p->data = array(array(array("-5",48.25),array("10",238.75),array("25",95.50),array("16",300.50),array("5",286.80),array("40",400)),array(array("5",300.25),array("15",225.75),array("24",44.50),array("50",259.50),array("28",250.80),array("15",300)));

$p->chart_type = "line";

// Common Options
$p->title = "Sales - 2014 vs 2015";
$p->ylabel = "Sales";
$p->series_label = array("2014","2015");

$p->options["axes"]["yaxis"]["tickOptions"]["prefix"] = '$';

$out = $p->render('c1');
?>
<!DOCTYPE html>
<html>
	<head>
		<script src="../../lib/js/jquery.min.js"></script>
		<script src="../../lib/js/chartphp.js"></script>
		<link rel="stylesheet" href="../../lib/js/chartphp.css">
	</head>
	<body>
		<div style="width:40%; min-width:450px;">
			<?php echo $out; ?>
		</div>
	</body>
</html>
