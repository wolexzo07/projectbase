<?php


function form_one($a,$b,$c,$d,$t,$p){

return round(exp(((-$a/($t*$t)) + $b - ($c * log($p)) + ($d/($p*$p)))),4);

}

function form_two($a,$b,$c,$d,$t,$p){

return  round(exp(((-$a/($t*$t)) + $b - ($c * log($p)) + ($d/($p)))),4);

}

function form_three($a,$b,$c,$t,$p){

return  round(exp(((-$a/($t)) + $b - ($c * log($p)))),4);

}

function liquid($z,$ng,$k){
	
	return round($z/(1+$ng*($k-1)),3);
	
	}
	
	function gas($z,$nl,$k){
		
		return round($z/(1+$nl*((1/$k)-1)),3);
		
		
		}


/*
echo form_one(292860,8.2445,0.8951,59.8465,$t,$p)."\methane";

echo form_one(600076.9,7.90595,0.84677,42.94594,$t,$p) ."ethylene";


* 
* 
* echo form_one(687248.2,7.90694,0.866,49.02654,$t,$p) ."ethane";
* 
* echo form_one(923484.7,7.71725,0.87871,47.67624,$t,$p) ."propylene";
* 
* echo form_one(1166846,7.72668,0.92213,0,$t,$p) ."ibutane";
* 
*  echo form_one(1280557,7.94986,0.96455,0,$t,$p) ."nbutane";
* 
* echo form_one(1481583,7.58071,0.93159,0,$t,$p) ."i-pentane";
* 
* echo form_one(1524891,7.33129,0.89143,0,$t,$p) ."n-pentane";
* 
*  echo form_one(1778901,6.96783,0.84634,0,$t,$p) ."n-hexane";
* 
* echo form_one(2013803,6.52914,0.79543,0,$t,$p) ."n-heptane";
* 
* echo form_one(2551040,5.69313,0.67818,0,$t,$p) ."n-nonane";
* 
* echo form_two(970688.6,7.15059,0.76984,6.9022,$t,$p) propane;
* 
echo form_three(7646.816,12.48457,0.73152,$t,$p).octane;
* 
* echo form_three(9760.457,13.80354,0.7147,$t,$p).decane;
* 
* 

*/


?>
